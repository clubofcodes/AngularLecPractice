export interface iStudent {
  _id: string,
  fullname: string,
  uid: string,
  username: string,
  password: string,
  department: string,
  cellno: string,
  dob: string,
  gender: string
}
