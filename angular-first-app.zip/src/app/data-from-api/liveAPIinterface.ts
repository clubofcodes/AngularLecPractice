export interface liveapiI{
  id:number,
  node_id:string,
  name:string,
  private:boolean
}
