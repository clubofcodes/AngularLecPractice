interface res{
  sem:any,
  sgpa:any,
  cgpa:any
}
export interface iResult{
    allres: res[]
}
